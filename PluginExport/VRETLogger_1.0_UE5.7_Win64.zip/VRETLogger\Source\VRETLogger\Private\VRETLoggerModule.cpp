// Fill out your copyright notice in the Description page of Project Settings.

#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FDefaultModuleImpl, VRETLogger);
